# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 08:30:00 2022

@author: Jhonatan Martínez
"""

from flask_mail import Mail

# Variable db para enviar correos
email = Mail()
