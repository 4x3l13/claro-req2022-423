# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 08:30:00 2022

@author: Jhonatan Martínez
"""

from flask_sqlalchemy import SQLAlchemy

# Variable db para usar los modelos del ORM
db = SQLAlchemy()
